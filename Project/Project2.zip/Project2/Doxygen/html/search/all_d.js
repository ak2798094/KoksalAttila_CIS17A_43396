var searchData=
[
  ['winner_33',['winner',['../class_board.html#a67eeec840d17ab997e32234493ac7e39',1,'Board']]]
];
