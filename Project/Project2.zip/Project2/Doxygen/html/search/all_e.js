var searchData=
[
  ['x_34',['x',['../struct_coordinate.html#ad462d671f1feb865911333e3ff5f0a5d',1,'Coordinate']]]
];
