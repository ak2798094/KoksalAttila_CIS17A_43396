var searchData=
[
  ['announcewinner_43',['announceWinner',['../class_game.html#a79027358777870aef2d8b6201fd5cedd',1,'Game::announceWinner()'],['../class_board.html#a087b47b13a82512788b58e34028f8257',1,'Board::announceWinner()']]]
];
