var searchData=
[
  ['increasenumberofturns_53',['increaseNumberOfTurns',['../class_board.html#a45a92fbfc6df3d11e82c197397c1f936',1,'Board']]],
  ['initializeboard_54',['initializeBoard',['../class_board.html#a06c43f3ee4262259aa3535990ccd59f2',1,'Board']]],
  ['isundercheck_55',['isUnderCheck',['../class_board.html#a6c0a5cf6bc9320d08fdf9a3d514cecaf',1,'Board']]]
];
