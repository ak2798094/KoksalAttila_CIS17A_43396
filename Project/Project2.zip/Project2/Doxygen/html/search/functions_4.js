var searchData=
[
  ['getallmovablelocations_47',['getAllMovableLocations',['../class_board.html#a3e585c2efd00e1d871ebb1045b0e4fa2',1,'Board']]],
  ['getcolor_48',['getColor',['../class_space.html#ac56272d972f2d2dfb136a5c3e539ebac',1,'Space']]],
  ['getmovablelocations_49',['getMovableLocations',['../class_board.html#a158e1994a63498038bb3786cb30b41ae',1,'Board']]],
  ['getplayername_50',['getPlayerName',['../class_game.html#a3f2206c85c6e515415c8e7a3bbd2fdca',1,'Game']]],
  ['getspace_51',['getSpace',['../class_board.html#a57e019c3904393258b74eb723555772e',1,'Board']]],
  ['getvalue_52',['getValue',['../class_space.html#af8b1866f0157528fe520eb532bcb2eff',1,'Space']]]
];
