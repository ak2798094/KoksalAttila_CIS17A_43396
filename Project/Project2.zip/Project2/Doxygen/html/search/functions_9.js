var searchData=
[
  ['searchandadd_61',['searchAndAdd',['../class_board.html#a59297fa71e8653617ef858cfb76a42cf',1,'Board']]],
  ['setpiece_62',['setPiece',['../class_board.html#a5fb0b9af3be98b861dcd78c6549b5154',1,'Board']]],
  ['setplayername_63',['setPlayerName',['../class_game.html#a9be50c324abced2c30c6d49e9654cdf0',1,'Game']]],
  ['setvalue_64',['setValue',['../class_space.html#af3f5e4c15ae2056e36bceefcb629f6e1',1,'Space']]]
];
