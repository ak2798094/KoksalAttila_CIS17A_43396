var searchData=
[
  ['piecenames_66',['pieceNames',['../main_8cpp.html#aad19715354828831406f316703e9f0c4',1,'main.cpp']]]
];
