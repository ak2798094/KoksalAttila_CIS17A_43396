var searchData=
[
  ['y_70',['y',['../struct_coordinate.html#a5c7d59f0f65ff9371b6c3791f78880aa',1,'Coordinate']]]
];
