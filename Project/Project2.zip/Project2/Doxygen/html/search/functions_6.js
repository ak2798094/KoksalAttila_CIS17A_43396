var searchData=
[
  ['maxitem_56',['maxItem',['../class_game.html#aa32da839bd667fb15439ea8c895e591c',1,'Game']]],
  ['menu_57',['menu',['../class_game.html#abee4e161ecf81d386c68e3dc411b06f9',1,'Game::menu()'],['../class_board.html#ab6182dc30b3e554a0e16e313aae84dfe',1,'Board::menu(int input)']]],
  ['movepiece_58',['movePiece',['../class_board.html#a991f7389c8fc8fb6a7c7009235e18093',1,'Board']]]
];
