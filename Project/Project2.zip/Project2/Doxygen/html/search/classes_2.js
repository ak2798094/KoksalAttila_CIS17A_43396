var searchData=
[
  ['coordinate_38',['Coordinate',['../struct_coordinate.html',1,'']]]
];
