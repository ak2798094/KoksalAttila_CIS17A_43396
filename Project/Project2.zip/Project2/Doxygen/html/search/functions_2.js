var searchData=
[
  ['displaywinningstatus_45',['displayWinningStatus',['../class_board.html#ad498bf71532c29eaf4edf05b94bbe4b1',1,'Board']]]
];
