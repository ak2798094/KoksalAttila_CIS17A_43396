var indexSectionsWithContent =
{
  0: "abcdfgimoprstwxy",
  1: "abcgst",
  2: "m",
  3: "acdfgimops",
  4: "cprwxy",
  5: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations"
};

