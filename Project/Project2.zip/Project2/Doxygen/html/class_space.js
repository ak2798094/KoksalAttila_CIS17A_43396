var class_space =
[
    [ "getColor", "class_space.html#ac56272d972f2d2dfb136a5c3e539ebac", null ],
    [ "getValue", "class_space.html#af8b1866f0157528fe520eb532bcb2eff", null ],
    [ "setValue", "class_space.html#af3f5e4c15ae2056e36bceefcb629f6e1", null ]
];