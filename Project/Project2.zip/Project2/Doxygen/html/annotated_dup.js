var annotated_dup =
[
    [ "a", "classa.html", null ],
    [ "Board", "class_board.html", "class_board" ],
    [ "Coordinate", "struct_coordinate.html", "struct_coordinate" ],
    [ "Game", "class_game.html", "class_game" ],
    [ "Space", "class_space.html", "class_space" ],
    [ "this", "classthis.html", null ]
];