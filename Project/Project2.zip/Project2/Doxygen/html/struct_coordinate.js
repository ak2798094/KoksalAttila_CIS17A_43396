var struct_coordinate =
[
    [ "operator==", "struct_coordinate.html#a803c20b0c173a04886ace0c4f6b14361", null ],
    [ "x", "struct_coordinate.html#ad462d671f1feb865911333e3ff5f0a5d", null ],
    [ "y", "struct_coordinate.html#a5c7d59f0f65ff9371b6c3791f78880aa", null ]
];