var main_8cpp =
[
    [ "Space", "class_space.html", "class_space" ],
    [ "Coordinate", "struct_coordinate.html", "struct_coordinate" ],
    [ "Game", "class_game.html", "class_game" ],
    [ "Board", "class_board.html", "class_board" ],
    [ "Color", "main_8cpp.html#ab87bacfdad76e61b9412d7124be44c1c", [
      [ "WHITE", "main_8cpp.html#ab87bacfdad76e61b9412d7124be44c1ca283fc479650da98250635b9c3c0e7e50", null ],
      [ "BLACK", "main_8cpp.html#ab87bacfdad76e61b9412d7124be44c1caf77fb67151d0c18d397069ad8c271ba3", null ],
      [ "NONE", "main_8cpp.html#ab87bacfdad76e61b9412d7124be44c1cac157bdf0b85a40d2619cbc8bc1ae5fe2", null ]
    ] ],
    [ "Piece", "main_8cpp.html#ade35c903123b92bed5cc7b84e6a1314e", [
      [ "Pawn", "main_8cpp.html#ade35c903123b92bed5cc7b84e6a1314eab306a6be286e11bcaf3695829cf657ee", null ],
      [ "Rook", "main_8cpp.html#ade35c903123b92bed5cc7b84e6a1314ea123c6e01d8a2e323abf42370c26cd047", null ],
      [ "Bishop", "main_8cpp.html#ade35c903123b92bed5cc7b84e6a1314ea7270f86db491d8aed7a3187829a82e13", null ],
      [ "Knight", "main_8cpp.html#ade35c903123b92bed5cc7b84e6a1314eacde4898e8fcebdba44f8963e9b12799d", null ],
      [ "Queen", "main_8cpp.html#ade35c903123b92bed5cc7b84e6a1314ea011d63789e83d8beb2a90652bb03cd31", null ],
      [ "King", "main_8cpp.html#ade35c903123b92bed5cc7b84e6a1314ea27fc6acdd76c4d0f3b47933e02ec65cf", null ],
      [ "Empty", "main_8cpp.html#ade35c903123b92bed5cc7b84e6a1314ea891fbec6fb0d74aea9e064d13b59c9e0", null ]
    ] ],
    [ "main", "main_8cpp.html#a3c04138a5bfe5d72780bb7e82a18e627", null ],
    [ "COLUMN", "main_8cpp.html#a66d279b709332d38b008aa88cfed97fd", null ],
    [ "pieceNames", "main_8cpp.html#aad19715354828831406f316703e9f0c4", null ],
    [ "ROW", "main_8cpp.html#a442a526f05e8429d610b777bb0a4446b", null ]
];