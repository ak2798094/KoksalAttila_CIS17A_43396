var hierarchy =
[
    [ "a", "classa.html", null ],
    [ "Coordinate", "struct_coordinate.html", null ],
    [ "Game", "class_game.html", [
      [ "Board", "class_board.html", null ]
    ] ],
    [ "Space", "class_space.html", null ],
    [ "this", "classthis.html", null ]
];