var class_board =
[
    [ "announceWinner", "class_board.html#a087b47b13a82512788b58e34028f8257", null ],
    [ "castleAttempt", "class_board.html#a6e5affecef98911f7e834a3f84debb16", null ],
    [ "displayWinningStatus", "class_board.html#ad498bf71532c29eaf4edf05b94bbe4b1", null ],
    [ "findAttackSquares", "class_board.html#acf2d9616a86a6a2266e201af6c6a85a9", null ],
    [ "getAllMovableLocations", "class_board.html#a3e585c2efd00e1d871ebb1045b0e4fa2", null ],
    [ "getMovableLocations", "class_board.html#a158e1994a63498038bb3786cb30b41ae", null ],
    [ "getSpace", "class_board.html#a57e019c3904393258b74eb723555772e", null ],
    [ "increaseNumberOfTurns", "class_board.html#a45a92fbfc6df3d11e82c197397c1f936", null ],
    [ "initializeBoard", "class_board.html#a06c43f3ee4262259aa3535990ccd59f2", null ],
    [ "isUnderCheck", "class_board.html#a6c0a5cf6bc9320d08fdf9a3d514cecaf", null ],
    [ "menu", "class_board.html#ab6182dc30b3e554a0e16e313aae84dfe", null ],
    [ "movePiece", "class_board.html#a991f7389c8fc8fb6a7c7009235e18093", null ],
    [ "printBoard", "class_board.html#aca49f093314a104381d05998bbf62f7f", null ],
    [ "searchAndAdd", "class_board.html#a59297fa71e8653617ef858cfb76a42cf", null ],
    [ "setPiece", "class_board.html#a5fb0b9af3be98b861dcd78c6549b5154", null ],
    [ "winner", "class_board.html#a67eeec840d17ab997e32234493ac7e39", null ]
];