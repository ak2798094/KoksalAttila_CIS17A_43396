var class_game =
[
    [ "announceWinner", "class_game.html#a79027358777870aef2d8b6201fd5cedd", null ],
    [ "getPlayerName", "class_game.html#a3f2206c85c6e515415c8e7a3bbd2fdca", null ],
    [ "maxItem", "class_game.html#aa32da839bd667fb15439ea8c895e591c", null ],
    [ "menu", "class_game.html#abee4e161ecf81d386c68e3dc411b06f9", null ],
    [ "setPlayerName", "class_game.html#a9be50c324abced2c30c6d49e9654cdf0", null ]
];