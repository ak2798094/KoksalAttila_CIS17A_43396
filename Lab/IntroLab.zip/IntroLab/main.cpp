/* 
 * File:   main.cpp
 * Author: Attila Koksal
 * Created on February 18, 2021, 9:37 PM
 * Purpose:  First Program "Hello World"
 */

//System Libraries
#include <iostream>  //I/O Library
using namespace std;

//User Libraries

//Global Constants
//Math, Science, Universal, Conversions, High Dimensioned Arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    
    //Initialize Variables
    
    //Map Inputs to Outputs -> Process
    
    //Display Inputs/Outputs
    cout<<"Hello World"<<endl;
    
    //Exit the Program - Cleanup
    return 0;
}